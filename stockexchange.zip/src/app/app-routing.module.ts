import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';
import { HomeComponent } from './home/home.component';
//import { AuthGuard } from './_guards/auth.guard';
import { RoleGuard } from './_guards/role.guard';
import { ProfileComponent } from './settings/profile/profile.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { MainLayoutComponent } from './main-layout/main-layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ChartsBuilderComponent } from './charts-builder/charts-builder.component';



const routes: Routes = [
  {
    path: '', component: LayoutComponent,
    children: [
      { path: '', component: HomeComponent }
    ],
  },
  {
    path: 'auth',
    loadChildren: 'app/auth/auth.module#AuthModule'
  },
  {
    path: 'admin',
    canActivate: [RoleGuard],
    data: { role: 1, breadcrumb: 'Home' },
    loadChildren: 'app/admin/admin.module#AdminModule'
  },
  {
    path: 'client',
    canActivate: [RoleGuard],
    data: { role: 2, breadcrumb: 'Home' },
    loadChildren: 'app/client/client.module#ClientModule'
  },
  {
    path: 'analyst',
    canActivate: [RoleGuard],
    data: { role: 3, breadcrumb: 'Home' },
    loadChildren: 'app/analyst/analyst.module#AnalystModule'
  },
  {
    path: 'editorier',
    canActivate: [RoleGuard],
    data: { role: 4, breadcrumb: 'Home' },
    loadChildren: 'app/editorier/editorier.module#EditorierModule'
  },
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: 'insights',
        loadChildren: 'app/insights/insights.module#InsightsModule',
      },
      {
        path: '',
        loadChildren: 'app/profiles/profiles.module#ProfilesModule',
      }
    ]
  },
  { path: "contact-us", component: ContactUsComponent },
  { path: "charts-builder", component: ChartsBuilderComponent },
  {
    path: '**',
    redirectTo: '/',
    pathMatch: 'full'
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
