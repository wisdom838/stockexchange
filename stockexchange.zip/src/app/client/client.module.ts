import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { ScriptService } from './../services/script.service';
import { ClientFormService } from './../services/clients/client-form.service';
import { SidebarComponent } from './widgets/sidebar/sidebar.component';
import { UtilsService } from '../services/utils.service';
import { ClientRoutingModule } from './client-routing.module';
import { ClientLayoutComponent } from './client-layout/client-layout.component';
import { RepeatModule } from '../repeat/repeat.module';
import { HelpFormService } from '../services/help/help-form.service';
import { HelpService } from '../services/help.service';
import { MessagesService } from '../services/messages.service';
import { MessagesFormService } from '../services/messages/messages-form.service';
import { UserService } from '../services/user.service';
import { SectorsService } from '../services/sectors.service';
import { SubsectorsService } from '../services/subsectors.service';
import { StatesService } from '../services/states.service';
import { CountriesService } from '../services/countries.service';
import { DataTablesModule } from 'angular-datatables';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LockerFormService } from './../services/lockers/locker-form.service';
import { LockersService } from './../services/lockers.service';
import { ClientGlobalSearchComponent } from './client-global-search/client-global-search.component';
import { CommodityService } from '../services/insights/commodity.service';
import { ComposeService } from '../services/compose.service';
import { InsightService } from '../services/insights/insight.service';
import { NotificationService } from '../services/notifications.service';
import { ClientAutoSearchComponent } from './client-auto-search/client-auto-search.component';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { 
  MatAutocompleteModule, 
  MatInputModule,
  MatSelectModule,

} from '@angular/material';
import { MyWatchListComponent } from './my-watch-list/my-watch-list.component';
import { ShareButtonsModule } from '@ngx-share/buttons';
//import { DashboardComponent } from '../admin/dashboard/dashboard.component';
//import { DashboardComponent } from '../dashboard/dashboard.component';

@NgModule({
  imports: [
    CommonModule,
    ClientRoutingModule,
    ReactiveFormsModule,
    RepeatModule,
    FormsModule,
    DataTablesModule,   
    MatAutocompleteModule,
    MatInputModule,  
    MatSelectModule,
    ShareButtonsModule,
    
  ],

  declarations: [
    //DashboardComponent,
    ClientLayoutComponent,
    SidebarComponent,
    ClientGlobalSearchComponent,
    ClientAutoSearchComponent,
    MyWatchListComponent
   
  ],
  providers: [
    ScriptService,
    UtilsService,
    DatePipe,
    ClientFormService,
    HelpFormService,
    MessagesFormService,
    UserService,
    HelpService,
    MessagesService,
    SectorsService,
    SubsectorsService,
    StatesService,
    CountriesService,
    LockerFormService,
    LockersService,
    CommodityService,
    ComposeService,
    InsightService,
    NotificationService
  ]
})


export class ClientModule { }


