import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import 'rxjs/add/operator/debounceTime';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
declare var $:any;



@Component({
  selector: 'app-client-global-search',
  templateUrl: './client-global-search.component.html',
  styleUrls: ['./client-global-search.component.css']
})
export class ClientGlobalSearchComponent implements OnInit {

  public searchResults = [];
  public hint : string = null;
  public showHint : boolean = true;

  globalForm: FormGroup = this.fb.group({
    term: [null, []]
  });

  constructor(private fb: FormBuilder,
      private _user:UserService,
      private router:Router) {

      }

  ngOnInit() {
    this.globalForm
      .valueChanges
      //.debounceTime(500)
      .subscribe(val => {
        if(val.term !== null){
          if(val.term.length < 3){
            let rem = 3-(val.term.length);
            this.hint = `Please enter ${rem} or more chracters`;
          }
          else{
            this.hint = null;
            this._user.globalSearch(val.term).subscribe(data=>{
              if(data.success){
                //this.convertToTemplateArray(data.data);
                this.searchResults = [data.data];
               
              }
              else{
                this.searchResults = [];
                this.hint = data.message;
              }
            });
          }
        }        
      });
  }


  // convertToTemplateArray(items){
  //   let htmlItems = [];
  //   Object.keys(items).forEach(key=>{
  //     switch(key) {
  //       case "users": {
  //         items[key].forEach(item=>{
  //           let html = `<div>
  //               <a routerLink='/client/home'>${item.first_name}</a>
  //               </div>`;
  //           htmlItems.push(html);
  //         })          
  //         break;
  //       }
  //       case "tickers": {
  //         items[key].forEach(item=>{
  //           let html = `<div>${item.name}</div>`;
  //           htmlItems.push(html);
  //         }) 
         
  //         break;
  //       }
  //       case "insights": {
  //         items[key].forEach(item=>{
  //           let html = `<div>${item.headline}</div>`;
  //           htmlItems.push(html);
  //         })
  //         break;
  //       }
  //       default: { 
  //         break;              
  //       } 
  //     }
  //   });
  //   this.searchResults = htmlItems;
  // }


  resetForm(){
    this.hint = null;
    setTimeout(()=>{ this.searchResults = [];},100);    
    this.globalForm.controls['term'].patchValue(null);
  }

  navigateMe(record,type){
    let path = '';
    switch(type) {
      case "user": {
        
        break;
      }
      case "insight":{
        break;
      }
      case "ticker":{
        break;
      }
      default:{
        break;
      }
    }
    alert('redirect here');
    //this.router.navigateByUrl(path);
  }

}
