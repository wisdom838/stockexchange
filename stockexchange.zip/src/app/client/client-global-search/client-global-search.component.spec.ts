import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientGlobalSearchComponent } from './client-global-search.component';

describe('ClientGlobalSearchComponent', () => {
  let component: ClientGlobalSearchComponent;
  let fixture: ComponentFixture<ClientGlobalSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientGlobalSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientGlobalSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
