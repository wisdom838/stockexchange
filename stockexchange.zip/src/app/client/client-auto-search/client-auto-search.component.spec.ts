import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientAutoSearchComponent } from './client-auto-search.component';

describe('ClientAutoSearchComponent', () => {
  let component: ClientAutoSearchComponent;
  let fixture: ComponentFixture<ClientAutoSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientAutoSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientAutoSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
