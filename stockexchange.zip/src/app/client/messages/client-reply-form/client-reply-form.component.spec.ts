import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientReplyFormComponent } from './client-reply-form.component';

describe('ClientReplyFormComponent', () => {
  let component: ClientReplyFormComponent;
  let fixture: ComponentFixture<ClientReplyFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientReplyFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientReplyFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
