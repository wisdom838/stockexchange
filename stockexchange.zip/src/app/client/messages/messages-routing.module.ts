import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientLayoutComponent } from '../client-layout/client-layout.component';
import { MessageFormComponent } from './message-form/message-form.component';
import { MessageFormListComponent } from './message-form-list/message-form-list.component';

const routes: Routes = [
  {
    path: 'read',
    redirectTo: 'read/',
    pathMatch: 'full'
  },
  { path: '', component: MessageFormListComponent },
  {
    path: 'read/:id', component: MessageFormListComponent,
    data: {
      breadcrumb: 'Read'
    }
  },
  {
    path: 'create', component: MessageFormComponent,
    data: {
      breadcrumb: 'Create'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MessagesRoutingModule { }
