import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MessagesRoutingModule } from './messages-routing.module';
import { MessageFormComponent } from './message-form/message-form.component';
import { RepeatModule } from '../../repeat/repeat.module';
import { DropzoneModule } from 'ngx-dropzone-wrapper';
import { MessageFormListComponent } from './message-form-list/message-form-list.component';
import { ClientReplyFormComponent } from './client-reply-form/client-reply-form.component';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
    imports: [
      CommonModule,
      MessagesRoutingModule,  
      FormsModule,
      ReactiveFormsModule,
      RepeatModule,
      DropzoneModule,
      DataTablesModule
    ],
    declarations: [MessageFormComponent, MessageFormListComponent, ClientReplyFormComponent]
  })
  export class MessagesModule { }
  