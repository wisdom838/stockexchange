import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientLayoutComponent } from '../client-layout/client-layout.component';
import { CreateHelpFormComponent } from '../help/create-help-form/create-help-form.component';
import { CreateHelpListComponent } from './create-help-list/create-help-list.component';
import { HelpViewComponent } from './help-view/help-view.component';

const routes: Routes = [

  // { path: 'create', component: CreateHelpFormComponent },
  {
    path: '', component: CreateHelpListComponent,
  },
  {
    path: 'create', component: CreateHelpFormComponent,
    data: {
      breadcrumb: 'Create'
    }
  },

  {
    path: 'read/:id', component: HelpViewComponent,
    data: {
      breadcrumb: 'Read'
    }
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HelpRoutingModule { }
