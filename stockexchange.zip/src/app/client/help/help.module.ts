import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HelpRoutingModule } from './help-routing.module';
import{CreateHelpFormComponent} from '../help/create-help-form/create-help-form.component';
import{CreateHelpListComponent} from './create-help-list/create-help-list.component';
import { ScriptService } from './../../services/script.service';
import { RepeatModule } from '../../repeat/repeat.module';

import { DropzoneModule } from 'ngx-dropzone-wrapper';
import { DataTablesModule } from 'angular-datatables';
import { DropzoneConfigInterface } from 'ngx-dropzone-wrapper/dist/lib/dropzone.interfaces';

//import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { HelpViewComponent } from './help-view/help-view.component';
import { HelpreplyFormComponent } from './helpreply-form/helpreply-form.component';

@NgModule({
  imports: [
    CommonModule,
    HelpRoutingModule,
    DataTablesModule,
    FormsModule,
    ReactiveFormsModule,
    RepeatModule,
    DropzoneModule,
    //InfiniteScrollModule
  ],
  declarations: [
    CreateHelpFormComponent,
    CreateHelpListComponent,
    HelpViewComponent,
    HelpreplyFormComponent
  ],
  exports: [
  ]  
})
export class HelpModule { }
