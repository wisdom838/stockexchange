import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpreplyFormComponent } from './helpreply-form.component';

describe('CreateHelpListComponent', () => {
  let component: HelpreplyFormComponent;
  let fixture: ComponentFixture<HelpreplyFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HelpreplyFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpreplyFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
