import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateHelpListComponent } from './create-help-list.component';

describe('CreateHelpListComponent', () => {
  let component: CreateHelpListComponent;
  let fixture: ComponentFixture<CreateHelpListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateHelpListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateHelpListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
