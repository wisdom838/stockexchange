import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HelpService } from '../../../services/help.service';
import { UtilsService } from '../../../services/utils.service';
import { HelpModel } from '../../../models/help.model';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Meta } from '@angular/platform-browser';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import { Router } from '@angular/router';
import { ENV } from '../../../env.config';


@Component({
  selector: 'app-create-help-list',
  templateUrl: './create-help-list.component.html',
  styleUrls: ['./create-help-list.component.css']
})
export class CreateHelpListComponent implements OnInit {

  public serverURL = ENV.SERVER_URL;
  currentUserId = JSON.parse(localStorage.getItem('currentUser')).user.userid;
  objLen:number = 10;
  public noRecords :boolean = true;
  dtOptions = { 
    "draw": 1, 
    "columns": [
      { "data": "subject", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
      { "data": "status", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
      { "data": "description", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
      { "data": "createdBy", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
      { "data": "id", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } }],
      "order": [
          { "column": "createdAt", "dir": "desc" }
      ],
      "start": 0,
      "length": this.objLen,
      "currentUserId" :this.currentUserId, 
      "search": { "value": "", "regex": false }
    };
  finished = false  // boolean when end of database is reached

  error: boolean;
  apiEvents = [];
  problems= [];
  switch:string = 'grid-item';
  
  probFilterForm: FormGroup = this.fb.group({
    sortBy: ['recent'],
    status: [''],
    quickFilter: [''],
  });


  constructor(

    private http: HttpClient,
    private router : Router,
    private _helpService: HelpService,
    private _utils: UtilsService,
    private meta: Meta,
    public toastr: ToastsManager,
    private fb: FormBuilder
  ) { }

  ngOnInit() {
    let currentUser = JSON.parse(localStorage.getItem('currentUser'));
    this.dtOptions.columns[3].search['value'] = currentUser.user.userid;
    this.getProblems();
    this.onChanges();
  }

  onChanges(){
    this.probFilterForm.valueChanges
              .debounceTime(500)
              .distinctUntilChanged()
              .subscribe(val => {
      this.dtOptions.columns[1].search['value'] = val.status;
      this.dtOptions.search = { "value": val.quickFilter, "regex": false };
      this.dtOptions.order[0].dir = (val.sortBy === 'recent') ? "desc" : 'asc';
      this.dtOptions.start = 0;
      this.dtOptions.length = this.objLen;
      this.finished = false;
      this.problems = [];    
      this.getProblems();
    });
  }

  onScroll () {
    this.dtOptions.start += this.objLen;
    this.getProblems();
  }
  selectCompany(company){
    this.router.navigateByUrl(`/company/`+company )
  }
  selectUser(id){
    this.router.navigateByUrl(`/profile/`+id )
  }
  private getProblems(append=true) {
    if (this.finished) return;

    this._helpService
        .filterProblems$(this.dtOptions,'filter-problems')
        .subscribe(data => {    
          if (this.noRecords && data.data.length) {
            this.noRecords = false;
          }        
          if(data.data.length !== this.objLen){
            this.finished = true;
          }
          this.problems = (this.problems).concat(data.data);
        })        
  }


}