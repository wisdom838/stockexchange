import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RepeatModule } from '../../repeat/repeat.module';
import { DropzoneModule } from 'ngx-dropzone-wrapper';
import { ClientlockersRoutingModule } from './clientlockers-routing.module';
import { ClientlockersFormComponent } from './clientlockers-form/clientlockers-form.component';
import { ClientlockersListComponent } from './clientlockers-list/clientlockers-list.component';

@NgModule({
  imports: [
    CommonModule,
    RepeatModule,
    FormsModule,
    ReactiveFormsModule,
    DropzoneModule,
    ClientlockersRoutingModule
  ],
  declarations: [ClientlockersFormComponent, ClientlockersListComponent]
})
export class ClientlockersModule { }
