import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientlockersFormComponent } from './clientlockers-form/clientlockers-form.component';
import { ClientlockersListComponent } from './clientlockers-list/clientlockers-list.component';

const LockerRoutes: Routes = [

  // { path: 'create', component: CreateHelpFormComponent },
  { path: '', component: ClientlockersFormComponent },

  {
    path: 'create', component: ClientlockersListComponent,
    data: {
      breadcrumb: 'Create'
    }
  },


];

@NgModule({
  imports: [RouterModule.forChild(LockerRoutes)],
  exports: [RouterModule]
})
export class ClientlockersRoutingModule { }
