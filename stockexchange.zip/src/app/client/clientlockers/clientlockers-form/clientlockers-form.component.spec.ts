import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientlockersFormComponent } from './clientlockers-form.component';

describe('ClientlockersFormComponent', () => {
  let component: ClientlockersFormComponent;
  let fixture: ComponentFixture<ClientlockersFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientlockersFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientlockersFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
