import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientlockersListComponent } from './clientlockers-list.component';

describe('ClientlockersListComponent', () => {
  let component: ClientlockersListComponent;
  let fixture: ComponentFixture<ClientlockersListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientlockersListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientlockersListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
