import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { ClientLayoutComponent } from './client-layout/client-layout.component';
import { ClientAutoSearchComponent } from './client-auto-search/client-auto-search.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  { path: 'auto', component: ClientAutoSearchComponent },

  {
    path: '', component: ClientLayoutComponent,
    children: [
      { path: 'settings', loadChildren: 'app/client/settings/settings.module#SettingsModule' },
      {
        path: 'help',
        data: {
          breadcrumb: 'Help'
        }, loadChildren: 'app/client/help/help.module#HelpModule'
      },
            { path: 'messages', loadChildren: 'app/client/messages/messages.module#MessagesModule' },
      {
        path: 'lockers',
        data: {
          breadcrumb: 'Lockers'
        }, loadChildren: 'app/client/clientlockers/clientlockers.module#ClientlockersModule'
      },
      { path: 'insights', loadChildren: 'app/client/client-insights/client-insights.module#ClientInsightsModule' },
      {
        path: 'home',
        children: [
          { path: '', loadChildren: 'app/dashboard/dashboard.module#DashboardModule' }
        ]
      },
      // {
      //   path: '',
      //   children: [
      //     { path: '', loadChildren: 'app/profiles/profiles.module#ProfilesModule' }
      //   ]
      // }
    ]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientRoutingModule { }
