import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientAllInsightsComponent } from './client-all-insights/client-all-insights.component';

const routes: Routes = [

  {
    path: '', component: ClientAllInsightsComponent,
    data: {
      breadcrumb: 'Insights'
    },
  },
  { path: 'compose', loadChildren: 'app/client/client-insights/client-compose/client-compose.module#ClientComposeModule' }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientInsightsRoutingModule { }
