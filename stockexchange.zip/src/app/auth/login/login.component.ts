import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private fb: FormBuilder, 
    private authService: AuthService,
    private router: Router,
    public toastr: ToastsManager) {
  }

  loginForm: FormGroup = this.fb.group({
    email: [null, [Validators.required, Validators.email]],
    password: [null, Validators.required],
  });

  loginUser(formdata:any): void {
    
    if (this.loginForm.dirty && this.loginForm.valid) {
      this.authService.login(this.loginForm.value)
  
        .subscribe(data => {
          if (data.success === false) {  
           
            this.toastr.error(data.message,'Invalid');
            
          } else {
            this.toastr.success('You have been successfully logged in.','Success');
            //if(data.data.access_level === 1)this.router.navigate(['/admin']);
            if(data.data.access_level === 1){
              let url = (data.data.status === 'active') ? ['/admin'] : ['/auth/updateprofile'];
              this.router.navigate(url);              
            }    
            else if(data.data.access_level === 2){
              let url = (data.data.status === 'active') ? ['/client'] : ['/auth/updateprofile'];
              this.router.navigate(url);              
            }    
            else if(data.data.access_level === 3){
              let url = (data.data.status === 'active') ? ['/analyst'] : ['/auth/updateprofile'];
              this.router.navigate(url);              
            } 
            else if(data.data.access_level === 4){
              let url = (data.data.status === 'active') ? ['/editorier'] : ['/auth/updateprofile'];
              this.router.navigate(url);              
            }         
            //else if(data.data.access_level === 3)this.router.navigate(['/analyst']);
            //else if(data.data.access_level === 4)this.router.navigate(['/editorier']);
            else this.router.navigate(['/auth/login']);
          }
          this.loginForm.reset();
        });
    }
  }

  ngOnInit() {

  }

}
