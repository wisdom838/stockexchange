import { NgModule } from '@angular/core';
import { CommonModule,DatePipe } from '@angular/common';
import { AnalystRoutingModule } from './analyst-routing.module';
import { AnalystLayoutComponent } from './analyst-layout/analyst-layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RepeatModule } from '../repeat/repeat.module';
import { SidebarComponent } from './widgets/sidebar/sidebar.component';
import { ScriptService } from '../services/script.service';
import { UserService } from '../services/user.service';
import { UtilsService } from '../services/utils.service';
import { ClientFormService } from './../services/clients/client-form.service';
import { SectorFormService} from '../services/sectors/sector-form.service';
import { SectorsService } from '../services/sectors.service';
import { SubsectorsService } from '../services/subsectors.service';
import { CountriesService } from '../services/countries.service';
import { StatesService } from '../services/states.service';
import { MessagesService } from '../services/messages.service';
import { HelpFormService } from '../services/help/help-form.service';
import { HelpService } from '../services/help.service';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MessagesFormService } from '../services/messages/messages-form.service';
import { DataTablesModule } from 'angular-datatables';
import { LockerFormService } from '../services/lockers/locker-form.service';
import { LockersService } from '../services/lockers.service';

import { ComposeService } from '../services/compose.service';
import { CommodityService } from '../services/insights/commodity.service';
import { NotificationService } from '../services/notifications.service';
import { InsightService } from '../services/insights/insight.service';
import { AnalystGlobalSearchComponent } from './analyst-global-search/analyst-global-search.component';
import { 
  MatAutocompleteModule,
  // MatButtonModule,
  // MatButtonToggleModule,
  // MatCardModule,
  // MatCheckboxModule,
  // MatChipsModule,
  // MatStepperModule,
  // MatDatepickerModule,
  // MatDialogModule,
  // MatExpansionModule,
  // MatGridListModule,
  // MatIconModule,
  MatInputModule,
  // MatListModule,
  // MatMenuModule,
  // MatNativeDateModule,
  // MatPaginatorModule,
  // MatProgressBarModule,
  // MatProgressSpinnerModule,
  // MatRadioModule,
  // MatRippleModule,
  MatSelectModule,
  // MatSidenavModule,
  // MatSliderModule,
  // MatSlideToggleModule,
  // MatSnackBarModule,
  // MatSortModule,
  // MatTableModule,
  // MatTabsModule,
  // MatToolbarModule,
  // MatTooltipModule
} from '@angular/material';
import { ShareButtonsModule } from '@ngx-share/buttons';
import { MacroTypeService } from '../services/macrotype.service';

@NgModule({
  imports: [
    CommonModule,
    AnalystRoutingModule,
    ReactiveFormsModule,
    RepeatModule,
    FormsModule,
    DataTablesModule,
    MatAutocompleteModule,
    // MatButtonModule,
    // MatButtonToggleModule,
    // MatCardModule,
    // MatCheckboxModule,
    // MatChipsModule,
    // MatStepperModule,
    // MatDatepickerModule,
    // MatDialogModule,
    // // MatExpansionModule,
    // MatGridListModule,
    // MatIconModule,
     MatInputModule,
    // MatListModule,
    // MatMenuModule,
    // MatNativeDateModule,
    // MatPaginatorModule,
    // MatProgressBarModule,
    // MatProgressSpinnerModule,
    // MatRadioModule,
    // MatRippleModule,
    MatSelectModule,
    // MatSidenavModule,
    // MatSliderModule,
    // MatSlideToggleModule,
    // MatSnackBarModule,
    // MatSortModule,
    // MatTableModule,
    // MatTabsModule,
    // MatToolbarModule,
    // MatTooltipModule,
    ShareButtonsModule.forRoot()
  ],
  declarations: [
    AnalystLayoutComponent,
    DashboardComponent,
    SidebarComponent,
    AnalystGlobalSearchComponent,  
  ],
  providers: [
    ScriptService,
    UserService,
    UtilsService,
    DatePipe,
    ClientFormService,
    MessagesFormService,
    SectorFormService,
    SectorsService,
    SubsectorsService,
    CountriesService,
    StatesService,
    HelpFormService,
    HelpService,
    MessagesService,
    LockerFormService,
    LockersService,
    ComposeService,
    CommodityService,
    NotificationService,
    InsightService,
    MacroTypeService
  ]
})
export class AnalystModule { }
