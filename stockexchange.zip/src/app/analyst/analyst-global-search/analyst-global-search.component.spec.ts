import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalystGlobalSearchComponent } from './analyst-global-search.component';

describe('AnalystGlobalSearchComponent', () => {
  let component: AnalystGlobalSearchComponent;
  let fixture: ComponentFixture<AnalystGlobalSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalystGlobalSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalystGlobalSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
