import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AnalystLayoutComponent } from './analyst-layout/analyst-layout.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: '', component: AnalystLayoutComponent,
    children: [
      { path: 'settings', loadChildren: 'app/analyst/settings/settings.module#SettingsModule' },
      {
        path: 'help', data: {
          breadcrumb: 'Help'
        }, loadChildren: 'app/analyst/analysthelp/analysthelp.module#AnalysthelpModule'
      },
      { path: 'home', component: DashboardComponent },
      { path: 'lockers', loadChildren: 'app/analyst/analystlocker/analystlocker.module#AnalystlockerModule' },
      { path: 'messages', loadChildren: 'app/analyst/messages/messages.module#MessagesModule' },
      { path: 'insights', loadChildren: 'app/analyst/analyst-insights/analyst-insights.module#AnalystInsightsModule' },
      // {
      //   path: '', 
      //   children:[
      //    {path:'',loadChildren: 'app/profiles/profiles.module#ProfilesModule'}
      //   ] 
      // } 
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnalystRoutingModule { }
