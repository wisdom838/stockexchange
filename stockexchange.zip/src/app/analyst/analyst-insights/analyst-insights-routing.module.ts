import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllInsightsComponent } from './all-insights/all-insights.component';
import { NonPubllishInisghtsComponent } from './non-publlish-inisghts/non-publlish-inisghts.component';

const routes: Routes = [
  {
    path: '', component: AllInsightsComponent,
    data: {
      breadcrumb: 'Insights'
    },
  },
  {
    path: 'my-insights', component: NonPubllishInisghtsComponent,
    data: {
      breadcrumb: 'My-Insights'
    },
  },
  { path: 'compose', loadChildren: 'app/analyst/analyst-insights/compose/compose.module#ComposeModule' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnalystInsightsRoutingModule { }
