import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { ComposeService } from '../../../../services/compose.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { UtilsService } from '../../../../services/utils.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ComposeModel } from '../../../../models/compose.model';
import { ToastsManager } from 'ng2-toastr';
import { UserService } from '../../../../services/user.service';
import { ENV } from '../../../../env.config';
import { NotificationService } from '../../../../services/notifications.service';
@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css']
})
export class PreviewComponent implements OnInit {

  @Input() event: ComposeModel;
  isEdit: boolean;
  insightsData: any;
  public id: number;
  private type: any;
  routeSub: Subscription;
  apiEvents = [];
  adminList = [];
  insightsData1 = [] 
  insightsData2 = []
  finished: boolean = false;
  public serverURL = ENV.SERVER_URL; 
  submitEventObj: ComposeModel;
  submitting: boolean;
  submitEventSub: Subscription;
  error: boolean;
  reply: boolean;
  userid:number;
  loading: boolean;
  isPushed: boolean = false;
  public replyFor = null;
  submitBtnText: string;
  AdminsList:any;
  AdminsId = [];
  currentUser = JSON.parse(localStorage.getItem('currentUser')).user;
  currentUserId = JSON.parse(localStorage.getItem('currentUser')).user.userid;
  whenPageLoad: boolean = true;
  public showForm={};
  public showComment={};


  private insightcommentId: number;
  objLen:number =10;
  dtOptions = { 
    "draw": 1,
      "order": [
          { "column": "createdAt", "dir": "desc" }
      ],
     "start": 0,

     "length": this.objLen,
  
     };
    
     insightscomments= [];
     switch:string = '';
     onScrollUp() {   
     
      this.dtOptions.start += this.objLen;
      this.finished = false;
      this.getInsightscomments();
      this.finished = true;
    }
  
    public getInsightscomments(append=true) {       
      this._composeapi.getInsightcommentById$(this.id,this.dtOptions).subscribe(data=> {      
         if(data.data.rows.length !== this.objLen){
          
          if(!append)this.insightsData1=[];
            if(data.data.rows.length){
            this.insightsData2 =(data.data.count);
            data.data.rows = this._utils.list_to_tree(data.data.rows);
            this.insightsData1 = (data.data.rows).concat(this.insightsData1);           
          }
          this.finished = true;
         } else {    
          if(data.data.rows.length)this.insightsData1 = (data.data.rows).concat(this.insightsData1);
          if(this.whenPageLoad){
            this.replyFor = ((this.insightsData1).length) ? this.insightsData1[this.insightsData1.length-1].pcid : null;
            this.whenPageLoad = false;
          }      
                 
        }  
 });
}
  constructor(
    private _composeapi: ComposeService,
    private route: ActivatedRoute,
    private _userapi: UserService,
    private _utils: UtilsService,
    private _notificationapi:NotificationService,
    private fb: FormBuilder,
    private router: Router,
    public toastr: ToastsManager,

  ) { }

  update(status) {
    let obj = {
      'id':this.id,
      'status':(status == 'remodify')?ENV.INSIGHT_STATUSES.ASSIGNED:ENV.INSIGHT_STATUSES.SUBMITTED
    }
    this._composeapi.publishEvent$(obj).subscribe(data => {
      if (data.success === false) {
      } else {
        this.finished = true;
        this.insightsData.status = ENV.INSIGHT_STATUSES.SUBMITTED
        let orgCopyobj = {
          'type':'insight',
          'type_id':this.insightsData.id,
          'data':JSON.stringify(this.insightsData)
        }
        this._notificationapi.orgCopy(orgCopyobj).subscribe(data => {
          if (data.success) {
          }
        });
      }
      if (data.success) {
        if( status !== 'remodify'){
          let notificationObj = {
            'type': this.type,
            'message': '<a href="#/admin/insights/compose/preview/'+this.insightsData.id+'">'+this.currentUser.first_name+' '+this.currentUser.last_name +'(Analyst) Posted an insight, Please assign this to editorial to verify & Publish '+'</a>',
            'from': this.currentUserId,
            'to': [this.AdminsId]
          }
          this._notificationapi.notification(notificationObj).subscribe(data => {
            if (data.success) {
              this.toastr.success(data.message, 'Success');
              this.router.navigate(['/analyst/insights/my-insights'])
            }
          });
        }else{
          let notificationObj = {
            'type': this.type,
            'message': '<a href="/#/editorier/insights/preview/'+this.insightsData.id+'">'+this.currentUser.first_name+' '+this.currentUser.last_name +'(Analyst) Remodify The  insight, Please Verify & Publish '+'</a>',
            'from': this.currentUserId,
            'to': [this.insightsData.editorierId]
          }
          this._notificationapi.notification(notificationObj).subscribe(data => {
            if (data.success) {
              this.toastr.success(data.message, 'Success');
              this.router.navigate(['/analyst/insights/my-insights'])
            }
          });
        }
      }
      else {
        this.toastr.error(data.message, 'Invalid');
      }
    });
  }
  AssignForm: FormGroup = this.fb.group({
    editorierId: [null, Validators.required],
  });
  ngOnInit() {

    this.reply = false;
    this.userid = this._userapi.getCurUserId();
    this.routeSub = this.route.params
    .subscribe(params => {
      this.id = params['id'];
    });
    this.routeSub = this.route.params
    .subscribe(params => {
      this.id = params['id'];
      this.insightcommentId = params['insightId'];
    });
      this._userapi.getUserList(1).subscribe(data => {
        if (data.success === false) {
        } else {
          this.AdminsList = data.data
          this.AdminsList.forEach(val => {
            this.AdminsId.push(val.id)
          })
        }
      })
    let apiEvent = this._composeapi.getComposeById$(this.id).subscribe(data => {
      if (data.success === false) {
      } else {
        this.finished = true;
        this.insightsData = data.data;
        this.type = this.insightsData.type;
      }
    });
    this._composeapi.getInsightcommentById$(this.id,this.dtOptions).subscribe(data=> {
      this.loading = true;
      this.finished = true;
      this.getInsightscomments();
        (this.apiEvents).push(apiEvent);  
    
      });
    } 
    selectUser(id){
      this.router.navigateByUrl(`/profile/`+id )
    }
    
  navigation1() { 
    if (this.id !== undefined) {
      if ((this.insightsData.status != 'submitted') && (this.insightsData.status != 'assigned') && (this.insightsData.status != 'published')) {
        this.router.navigateByUrl(`/analyst/insights/compose/summary/${this.id}`);
      }
    }
  }
  navigation() {
    if (this.id !== undefined) {
      if ((this.insightsData.status != 'submitted') && (this.insightsData.status != 'assigned') && (this.insightsData.status != 'published')) {
        this.router.navigateByUrl(`/analyst/insights/compose/pick-ticker/${this.type}/${this.id}`);
      }
    }
  }


onNotify(msgRec) {
  this.insightsData1.push(msgRec);
}
reply1() {
  this.reply = true;
  this.isPushed = true;
}

closeAllForms(){
  
  let t = this._utils.objLen(this.showForm);
  if(t){
   for(let k in this.showForm){
    this.showForm[k] = false;
   }
  }
}


replyToUpdate(obj={}){        
  this.replyFor = obj['rid'] || this.replyFor;  
 this.closeAllForms();
  this.getInsightscomments(false);   
   this.isPushed = false;
}


  private _handleSubmitSuccess(res) {
    this.error = false;
    this.submitting = false;
    // Redirect to event detail
    if (res.success) {
      this.toastr.success(res.message, 'Success');
    }
    else {
      this.toastr.error(res.message, 'Invalid');
    }
  }
  private _handleSubmitError(err) {
    this.toastr.error(err.message, 'Error');
    this.submitting = false;
    this.error = true;
  }

  switchForm(id){
    this.replyFor = id;
    this.showForm[id] = !this.showForm[id];
  }
  public ngOnDestroy() {
    if ((this.apiEvents).length) {
      this.apiEvents.forEach(val => {
        val.unsubscribe();
      })
    }
  }
}



