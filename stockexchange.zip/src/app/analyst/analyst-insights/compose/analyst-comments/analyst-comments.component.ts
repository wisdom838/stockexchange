import { Component, OnInit, Input, Output, ViewChild, OnDestroy, ElementRef, EventEmitter } from '@angular/core';
import { ComposeService } from '../../../../services/compose.service';
import { NotificationService } from '../../../../services/notifications.service';
import { InsightService } from '../../../../services/insights/insight.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UtilsService } from '../../../../services/utils.service';
import { UserService } from '../../../../services/user.service';
import { FormBuilder } from '@angular/forms';
import { ToastsManager } from 'ng2-toastr';
import { ENV } from '../../../../env.config';

@Component({
  selector: 'app-analyst-comments',
  templateUrl: './analyst-comments.component.html',
  styleUrls: ['./analyst-comments.component.css']
})
export class AnalystCommentsComponent implements OnInit {

  @Input('data') comment: any;
   id: number;
  routeSub: any;
  loading: boolean = false;
  finished: boolean = true;
  public comments = [];
  public serverURL = ENV.SERVER_URL;
  public showForm={};
  public replyFor = null;
  chg = false;
  insightsData1 = []
  insightsData2 = []
  whenPageLoad: boolean = true;
  isPushed: boolean = false;

  objLen: number = 40;
  dtOptions = {
    "draw": 1,
      "order": [
          { "column": "createdAt", "dir": "desc" }
      ],
     "start": 0,

     "length": this.objLen,
  
     };


  @Output() UpdateComments: EventEmitter<any> = new EventEmitter<any>();
  @Output() SelfUpdateComment: EventEmitter<any> = new EventEmitter<any>();
  

  constructor(
    private _composeapi: ComposeService,
    // private _notificationapi: NotificationService,
    // private is: InsightService,
     private route: ActivatedRoute,
     private _utils: UtilsService,    
     private _userapi: UserService,
    // private fb: FormBuilder,
    // private router: Router,
    // public toastr: ToastsManager,
  ) {
    this.routeSub = this.route.params
    .subscribe(params => {
      this.id = params['id'];
    }); }

  ngOnInit() {
    // if(this.id){
    //   this._composeapi.getInsightcommentById$(this.id).subscribe(data=> {
    //     this.comments= data.data;
    //     this.loading = true;
    //     this.finished = true;      
    //   });
      
    // }
   
    this.chg = true;
  }

// ngOnChanges(){
//   if(this.chg){

//   }
// }



  switchForm(id){
    this.replyFor = id;
    this.showForm[id] = !this.showForm[id];
  }
  
  replyToUpdate(obj){    
   this.showForm[this.replyFor] = !this.showForm[this.replyFor];
   this.SelfUpdateComment.emit({'rid': this.replyFor });
   this.UpdateComments.emit({'rid': this.replyFor });
     this.isPushed = false;
  }

  selfUpdate(obj){    
    this.showForm[this.replyFor] = !this.showForm[this.replyFor];
    this.SelfUpdateComment.emit({'rid': this.replyFor });
    this.UpdateComments.emit({'rid': this.replyFor });
      this.isPushed = false;
  }
}

