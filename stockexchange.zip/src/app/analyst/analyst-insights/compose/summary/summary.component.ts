import { Component, OnInit, Input, ViewChild, OnDestroy, Output, NgModule } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, AbstractControl } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';
import { ComposeFormService } from './../../../../services/compose/compose-form.service';
import { ComposeModel, FormComposeModel } from './../../../../models/compose.model';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { ComposeService } from './../../../../services/compose.service';
import { DropzoneModule } from 'ngx-dropzone-wrapper';
import { DropzoneConfigInterface } from 'ngx-dropzone-wrapper/dist/lib/dropzone.interfaces';
import { ENV } from './../../../../env.config';
import { EventEmitter } from '@angular/core'
import { InsightService } from '../../../../services/insights/insight.service';
import { UserService } from '../../../../services/user.service';
import { UtilsService } from '../../../../services/utils.service';

declare var $: any;
@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {

  @Input() event: ComposeModel;
  // @Output() edit: EventEmitter<any> = new EventEmitter<any>();
  isEdit: boolean;
  autosave: boolean = true;
  SummaryForm: FormGroup;
  apiEvents = [];
  // Model storing initial form values
  formEvent: FormComposeModel;
  // Form validation and disabled logic
  formErrors: any;
  formChangeSub: Subscription;
  // Form submission
  submitEventObj: ComposeModel;
  submitting: boolean;
  submitEventSub: Subscription;
  error: boolean;
  submitBtnText: string;
  public id: number;
  public type: any;
  routeSub: Subscription;
  insightsData: any;
  uploadFilesObj = {};
  uploadFiles = [];
  canRemove: boolean = true;
  public config: DropzoneConfigInterface = {};
  finished: boolean = false;
  insights = [];
  private summaryLimitChars = 200;
  private descriptionLimitChars = 500;
  filesToUpload: Array<File> = [];
  tickerInd = ENV['$'];
  analystInd = ENV['@'];
  InsightInd = ENV['#'];
  // showform:boolean=false;
  constructor(
    private fb: FormBuilder,
    private utils : UtilsService,
    private router: Router,
    private _is: InsightService,
    private _us: UserService,
    private route: ActivatedRoute,
    public cf: ComposeFormService,
    private _composeapi: ComposeService,
    public toastr: ToastsManager
  ) {
    this.SummaryForm = new FormGroup({
      headline: new FormControl(),
      summary: new FormControl(),
      description: new FormControl()
      //files: new FormControl()
    });
  }
  ngOnInit() {
    this.routeSub = this.route.params
      .subscribe(params => {
        this.id = params['id'];
        this.type = params['type'];
      });
    let apiEvent = this._composeapi.getComposeById$(this.id).subscribe(data => {
      if (data.success === false) {
      }
      else {
        this.finished = true;
        this.insightsData = data.data;
        this.type = this.insightsData.type
        this.SummaryForm.controls['headline'].patchValue(this.insightsData.headline);
        this.SummaryForm.controls['summary'].patchValue(this.insightsData.summary);
        this.SummaryForm.controls['description'].patchValue(this.insightsData.description);
        {
          let _that = this;
          $(document).ready(() => {
            
            $('#description').summernote({
              toolbar: ENV.SUMMER_SETUP.toolbar,
              buttons: {
                save: this.SaveButton(_that)
              },
              callbacks:{
                onImageUpload: function(files) 
                {
                  
                _that.uploadFile(files, this);
            },
              onCreateLink: function (originalLink) {
                return originalLink; // return original link 
              },
              hint: _that.utils.hint()
            }
            });
      
            $('#summary').summernote({
              toolbar: ENV.SUMMER_SETUP.toolbar,
              buttons: {
                save: this.SaveButton(_that) 
              },
              callbacks:{
              onImageUpload: function(files) 
              {
                
              _that.uploadFile(files, this);
          }
          },
              
              onCreateLink: function (originalLink) {
                return originalLink; // return original link 
              },
              hint: _that.utils.hint()
            });
          });
        }
      }
      if (this.insightsData.status == 'published') {
        this.autosave = false;
        this.router.navigate(['/analyst/insights/compose/preview',this.insightsData.id]);
        this.toastr.success('Already Published insight', 'Success');
      }
    });

    (this.apiEvents).push(apiEvent);
    this.formErrors = this.cf.formErrors;
    this.isEdit = !!this.event;
    this.submitBtnText = 'Continue';
    this.formEvent = this._setFormEvent();
    this._buildForm();
    let that = this;
    this.config = {
      url: ENV.BASE_API + 'insight/path?token=' + this._composeapi.getToken(),
      maxFiles: ENV.HELP_MAX_FILES,
      clickable: true,
      createImageThumbnails: true,
      addRemoveLinks: true,
      init: function () {
        let drop = this;

        this.on('removedfile', function (file) {

          /*If reupload already existed file, don t delet the file if max lik=mit crossed error uploaded*/
          if (file.status === 'error') {
            let index = (that.uploadFiles).indexOf(that.uploadFilesObj[file.upload.uuid]);
            if (index > -1) {
              return false;
            }
          }
          /*end*/

          if (that.canRemove) {
            //Removing values from array which are existing in uploadFiles variable         
            let index = (that.uploadFiles).indexOf(that.uploadFilesObj[file.upload.uuid]);
            if (index > -1) {
              if (that.uploadFiles.length === ENV.HELP_MAX_FILES) {
                that.formErrors['files'] = '';
                that._setErrMsgs(that.SummaryForm.get('files'), that.formErrors, 'files');
              }
              (that.uploadFiles).splice(index, 1);
              that.removeFile(that.uploadFilesObj[file.upload.uuid]);
              delete that.uploadFilesObj[file.upload.uuid];
            }
          }
        });
        this.on('error', function (file, errorMessage) {

          drop.removeFile(file);
        });

        this.on('success', function (file) {
        });

      }
    };
  };

  deleteInsightAttachment(id: number) {
    var delmsg = confirm("Are u Sure Want to delete?");
    if (delmsg) {
      let apiEvent = this._composeapi.deleteInsAttachmentById$(id)
        .subscribe(
          data => this._handleSubmitSuccess1(data, id),
          err => this._handleSubmitError(err)
        );

      (this.apiEvents).push(apiEvent);
    }
  }
  private _handleSubmitSuccess1(res, id = 0) {
    this.error = false;

    // Redirect to event detail
    if (res.success) {
      this.toastr.success(res.message, 'Success');
      let pos = this.insights.map(function (e) { return e.id; }).indexOf(id);
      this.insights.splice(pos, 1);
    }
    else {
      this.toastr.error(res.message, 'Invalid');
    }

  }

  uploadFile(files, editor) {
    
    // $('#files').uploadFile('add', {
    //    fileInput: files
    // });
  
   
  //  $(editor).summernote('insertImage', ENV.SERVER_URL,'');
 
      
  {
  const formData = new FormData();
  //const files: Array<File> = this.filesToUpload;

  for(let i =0; i < files.length; i++){
      formData.append("userphoto", files[i], files[i]['name']);
  }

   //formData.append("file",files[0],files[0].name);
   //formData.append("id", String(this.id));
   this._composeapi.uploads(formData).subscribe(res => {
     if (res.success) {
      res.data.forEach(path=>{
        $(editor).summernote('insertImage', ENV.SERVER_URL+path,'');
      })
     }
   });
   
}
  }

  change() {
    this.router.navigateByUrl(`/analyst/insights/compose/choose-type/${this.id}`);
  };

  navigation() {
    if (this.insightsData.status == 'preview') {
      this.router.navigateByUrl(`/analyst/insights/compose/preview/${this.id}`);
    } else {
      this.router.navigateByUrl(`/analyst/insights/compose/summary/${this.id}`);
    }
  };

  navigation1() {
    if (this.id !== undefined) {
      this.router.navigateByUrl(`/analyst/insights/compose/pick-ticker/${this.type}/${this.id}`);
    } else {
      this.router.navigateByUrl(`/analyst/insights/compose/summary/${this.id}`);
    }
  };

  private removeFile(file) {
    let apiEvent = this._composeapi.removeFile(file).subscribe(
      data => {
        this._handleSubmitSuccess(data);
      },
      err => this._handleSubmitError(err)
    );
    (this.apiEvents).push(apiEvent);
  };

  public onUploadSuccess(eve) {
    if ((eve[1].success !== undefined) && eve[1].success) {
      this.formErrors['files'] = '';
      //Object.assign(this.uploadFilesObj,{[eve[0].lastModified]:eve[1].data});
      Object.assign(this.uploadFilesObj, { [eve[0].upload.uuid]: eve[1].data });
      (this.uploadFiles).push(eve[1].data);
    }
    else {
      this.formErrors['files'] = 'Something Went Wrong';
    }
    this._setErrMsgs(this.SummaryForm.get('files'), this.formErrors, 'files');
  };

  public onUploadError(eve) {
    this.formErrors['files'] = eve[1];
    this._setErrMsgs(this.SummaryForm.get('files'), this.formErrors, 'files');
  };

  private _buildForm() {
    let validRules = {
      headline: [this.formEvent.headline, [
        Validators.required
      ]],
      summary: [this.formEvent.summary, [
        // Validators.required
      ]],
      description: [this.formEvent.description, [
        // Validators.required
      ]],
    };
    this.SummaryForm = this.fb.group(validRules);
    // Subscribe to form value changes
    let apiEvent = this.formChangeSub = this.SummaryForm
      .valueChanges
      .subscribe(data => this._onValueChanged());
    (this.apiEvents).push(apiEvent);
    if (this.isEdit) {
      const _markDirty = group => {
        for (const i in group.controls) {
          if (group.controls.hasOwnProperty(i)) {
            group.controls[i].markAsDirty();
          }
        }
      };
      _markDirty(this.SummaryForm);
    }
    this._onValueChanged();
  }

  private _setFormEvent() {
    if (!this.isEdit) {
      // If creating a new event, create new
      // FormEventModel with default null data
      return new FormComposeModel(null, null, null, null, null, null, []);
    } else {
      // If editing existing event, create new
      // FormEventModel from existing data
      return new FormComposeModel(
        this.event.headline,
        this.event.summary,
        this.event.bullbear,
        this.event.description,
        this.event.createdBy,
        this.event.updatedBy,
        this.event.files
      );
    }
  };

  private _onValueChanged() {
    if (!this.SummaryForm) { return; }
    // Check validation and set errors
    for (const field in this.formErrors) {
      if (this.formErrors.hasOwnProperty(field)) {
        this.formErrors[field] = '';
        this._setErrMsgs(this.SummaryForm.get(field), this.formErrors, field);
      }
    }
  }

  _setErrMsgs = (control: AbstractControl, errorsObj: any, field: string) => {
    if (control && control.dirty && control.invalid) {
      const messages = this.cf.validationMessages[field];
      for (const key in control.errors) {
        if (control.errors.hasOwnProperty(key)) {
          errorsObj[field] += messages[key] + '<br>';
        }
      }
    }
  };

  resetForm() {
    this.SummaryForm.reset();
    $("#summary").summernote("reset")
    $("#description").summernote("reset")
  };

  private _getSubmitObj() {
    let curUserObj = localStorage.getItem('currentUser');
    let currentUser = JSON.parse(curUserObj);

    return new ComposeModel(
      this.SummaryForm.get('headline').value,
      $('#summary').summernote('code'),
      null,
      $('#description').length ? $('#description').summernote('code') : null,
      this.event ? this.event.createdBy : currentUser.user.userid,
      currentUser.user.userid,
      (this.insightsData.status == 'remodify') ? 'remodify' : 'preview',
      this.event ? this.event.files : this.uploadFiles,
      this.event ? this.event.id : null,
    );
  };

  private _handleSubmitSuccess(res) {
    this.error = false;
    this.submitting = false;
    // Redirect to event detail
    if (res.success) {
      this.toastr.success(res.message, 'Success');
    }
    else {
      this.toastr.error(res.message, 'Invalid');
    }
  };

  private _handleSubmitError(err) {
    this.toastr.error(err.message, 'Error');
    this.submitting = false;
    this.error = true;
  };

  SaveButton = function (context) {
    var ui = $.summernote.ui;
    var button = ui.button({
      contents: '<i class="fa fa-floppy-o" aria-hidden="true"></i>',
      tooltip: 'save',
      click: function () {
        let apiEvent = context.postEvent()
      }
    });
    return button.render();
  };

  private postEvent() {
    this.submitEventObj = this._getSubmitObj();
    delete this.submitEventObj.status
    this.submitEventSub = this._composeapi
      .editEvent$(this.id, this.submitEventObj)
      .subscribe(
        data => {
        },
    );
  }

  saveSummary() {
    this.autosave = false;
    if ($('#summary').next('.note-editor').find('.note-editable').text().length < this.summaryLimitChars) {
      this.formErrors['summary'] = this.cf.validationMessages['summary'].required;
      this._setErrMsgs(this.SummaryForm.get('summary'), this.formErrors, 'summary');
      return false;
    }
    else {
      this.formErrors['summary'] = '';
      this._setErrMsgs(this.SummaryForm.get('summary'), this.formErrors, 'summary');
    }
    if (this.insightsData.type == 'In-depth') {
      if ($('#description').next('.note-editor').find('.note-editable').text().length < this.descriptionLimitChars) {
        this.formErrors['description'] = this.cf.validationMessages['description'].required;
        this._setErrMsgs(this.SummaryForm.get('description'), this.formErrors, 'description');
        return false;
      }
      else {
        this.formErrors['description'] = '';
        this._setErrMsgs(this.SummaryForm.get('description'), this.formErrors, 'description');
      }
    }
    this.submitting = true;
    this.submitEventObj = this._getSubmitObj();
    if (!this.isEdit) {
      let apiEvent = this.submitEventSub = this._composeapi
        .editEvent$(this.id, this.submitEventObj)
        .subscribe(
          data => {
            this.canRemove = false;
            this.router.navigate(["analyst/insights/compose/preview", this.id]);
            this._handleSubmitSuccess(data);
          },
          err => this._handleSubmitError(err)
        );
      (this.apiEvents).push(apiEvent);
    }
  }

  public ngOnDestroy() {
    if (this.autosave == true) {
      var confirmMsg = confirm("Are u Sure Want to Save?");
      if (confirmMsg) {
      let apiEvent = this.postEvent()
    }
  }
    if ((this.apiEvents).length) {
      this.apiEvents.forEach(val => {
        val.unsubscribe();
      })
    }
  }
}
