import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { ComposeService } from '../../../services/compose.service';
import { InsightService } from '../../../services/insights/insight.service';
import { ToastsManager } from 'ng2-toastr';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-choose-type',
  templateUrl: './choose-type.component.html',
  styleUrls: ['./choose-type.component.css']
})
export class ChooseTypeComponent implements OnInit {
  routeSub: Subscription;
  public id: number; 
  insightsData: any;
  formData:any;
  public selectValue : any;
  constructor(private router:Router,
    private route: ActivatedRoute,
    private _composeapi: ComposeService,
    private is: InsightService,
    public toastr: ToastsManager,
    private fb: FormBuilder,) { }

  ngOnInit() {
    this.routeSub = this.route.params
    .subscribe(params => {
      this.id = params['id']
    });
  }
  pickTickerForm: FormGroup = this.fb.group({
  });
  chooseMe(type){  
    this.selectValue =  type;
  }
countinue(type){
  if(this.id != undefined)
  {
    let formData = this.pickTickerForm.value;
    if(type == 'macro-type'){
      formData.tickerId = null;
      formData.commodityId = null;
    }
    formData.type = type;
    this.is.editEvent$(this.id,formData)
    .subscribe(data => {
      if(data.success){
        this.toastr.success(data.message,'Success');
        if(type !== 'macro-type'){
          this.router.navigateByUrl(`/analyst/insights/compose/pick-ticker/${type}/`+this.id);
        }else{
          this.router.navigateByUrl(`/analyst/insights/compose/pick-ticker/${type}/`+this.id);
        }
      }
      else{
        this.toastr.error(data.message,'error');
      }
    });
  }else{
    this.router.navigateByUrl(`/analyst/insights/compose/pick-ticker/${type}`);
  }
}
}
