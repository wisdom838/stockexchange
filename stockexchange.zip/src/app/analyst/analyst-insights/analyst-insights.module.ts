import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AnalystInsightsRoutingModule } from './analyst-insights-routing.module';
import { AllInsightsComponent } from './all-insights/all-insights.component';
import { DataTablesModule } from 'angular-datatables';
import { RepeatModule } from '../../repeat/repeat.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NonPubllishInisghtsComponent } from './non-publlish-inisghts/non-publlish-inisghts.component';
import { ShareButtonsModule } from '@ngx-share/buttons';
import { ChooseTypeComponent } from './choose-type/choose-type.component';
@NgModule({
  imports: [
    CommonModule,
    AnalystInsightsRoutingModule,
    DataTablesModule,
    RepeatModule,
    ReactiveFormsModule,
    FormsModule,
    ShareButtonsModule.forRoot()
  ],
  declarations: [AllInsightsComponent, NonPubllishInisghtsComponent]
})
export class AnalystInsightsModule { }
