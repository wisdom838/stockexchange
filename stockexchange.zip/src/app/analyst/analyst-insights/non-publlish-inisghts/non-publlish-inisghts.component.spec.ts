import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NonPubllishInisghtsComponent } from './non-publlish-inisghts.component';

describe('NonPubllishInisghtsComponent', () => {
  let component: NonPubllishInisghtsComponent;
  let fixture: ComponentFixture<NonPubllishInisghtsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NonPubllishInisghtsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NonPubllishInisghtsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
