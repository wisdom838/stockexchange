import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalysthelpreplyFormComponent } from './analysthelpreply-form.component';

describe('AnalysthelpreplyFormComponent', () => {
  let component: AnalysthelpreplyFormComponent;
  let fixture: ComponentFixture<AnalysthelpreplyFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalysthelpreplyFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalysthelpreplyFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
