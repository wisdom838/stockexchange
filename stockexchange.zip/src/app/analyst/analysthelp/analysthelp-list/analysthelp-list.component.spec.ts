import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalysthelpListComponent } from './analysthelp-list.component';

describe('AnalysthelpListComponent', () => {
  let component: AnalysthelpListComponent;
  let fixture: ComponentFixture<AnalysthelpListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalysthelpListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalysthelpListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
