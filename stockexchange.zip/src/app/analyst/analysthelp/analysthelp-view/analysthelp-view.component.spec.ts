import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalysthelpViewComponent } from './analysthelp-view.component';

describe('AnalysthelpViewComponent', () => {
  let component: AnalysthelpViewComponent;
  let fixture: ComponentFixture<AnalysthelpViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalysthelpViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalysthelpViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
