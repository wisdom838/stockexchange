import { Component, OnInit, ViewChild,ElementRef,AfterViewChecked} from '@angular/core';
import { Subscription } from 'rxjs';
import { HelpService } from '../../../services/help.service';
import { UtilsService } from '../../../services/utils.service';
import { Meta } from '@angular/platform-browser';
import { ToastsManager } from 'ng2-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../../services/user.service';
import { HelpModel } from '../../../models/help.model';
import { ENV } from './../../../env.config';
import { ClientModel } from '../../../models/client.model';
@Component({
  selector: 'app-analysthelp-view',
  templateUrl: './analysthelp-view.component.html',
  styleUrls: ['./analysthelp-view.component.css']
})
export class AnalysthelpViewComponent implements OnInit {

  @ViewChild('scrollMe') private myScrollContainer: ElementRef;
  

  routeSub: Subscription;
  private id: number;
  userSub: Subscription;
  userprofile: ClientModel;
  problem_files:HelpModel;
  private createdBy: number;

  public serverURL = ENV.SERVER_URL;
  public avatar: string = null;
  public files:string=null;
  loading: boolean;
  whenPageLoad: boolean = true;


  finished:boolean=false;
  private problemId: number;
  reply: boolean;
  problemsData: any;
  problemsData4:string;
  problemsData1 = []
  problemsData2=[]
  public replyFor = null;
  userid:number;
  isPushed: boolean = false;
  apiEvents=[];


  objLen:number =10;
  dtOptions = { 
    "draw": 1,
  
    // "columns": [
    //   { "data": "message", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
    //   { "data": "msgTo", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
    //   { "data": "first_name", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
    //   { "data": "last_name", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
    //   { "data": "id", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } }
    // ],
      "order": [
          { "column": "createdAt", "dir": "desc" }
      ],
     "start": 0,

     "length": this.objLen,
  
     };
  
    
   // boolean when end of database is reached
     error: boolean;
     problemscomments= [];
   
     switch:string = '';



     onScrollUp() {
    
     
      this.dtOptions.start += this.objLen;
      this.finished = false;
  
      this.getProblemscomments();
      this.finished = true;
    }
  
    private getProblemscomments(append=true) {
 
      //this._helpService.updateAllUnread(this.id,this._helpService.getUserId()).subscribe(data=>{});
      
      this._helpService.getHelpcommentById$(this.id,this.dtOptions).subscribe(data => {
         if(data.data.length !== this.objLen){
          data.data.reverse();
          if(data.data.length && (!this.problemsData1.length)){
            this.problemsData1 = (data.data).concat(this.problemsData1);
          }
           this.finished = true;
         } else {
          data.data.reverse();
          if(data.data.length)this.problemsData1 = (data.data).concat(this.problemsData1);
          if(this.whenPageLoad){
            this.replyFor = ((this.problemsData1).length) ? this.problemsData1[this.problemsData1.length-1].pcid : null;
            this.whenPageLoad = false;
          }
                 
        }  
 });
}

  constructor(
   
    private _helpService: HelpService,
    private _utils: UtilsService,
    private _userapi: UserService,
    private meta: Meta,
    public toastr: ToastsManager,
    private route: ActivatedRoute,
    private router:Router

  ) {
    this.reply = false;
    this.userid = this._userapi.getCurUserId();
    this.routeSub = this.route.params
      .subscribe(params => {
        this.id = params['id'];
        this.problemId=params['id']
      });

      this._helpService.updateAllUnread(this.id,this._helpService.getUserId()).subscribe(data=>{});
    //Fetch Messages based on Id
    this._helpService. getHelpById$(this.id).subscribe(data => {
      if (!data.data.length) {
        this.router.navigateByUrl('/analyst/help');
      } else {
        this.problemsData = data.data;
       
      }
    });
   }

   ngAfterViewChecked() {        
    //this.scrollToBottom();        
} 

scrollToBottom(): void {
    try {
        this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
    } catch(err) { }                 
}
ngOnInit() {

  //this.scrollToBottom();

    this.reply = false;
    this.userid = this._userapi.getCurUserId();
    this.routeSub = this.route.params
      .subscribe(params => {
        this.id = params['id'];
        this.problemId = params['problemId'];
      });
      

      
    //Fetch Messages based on Id
    let apiEvent= this._helpService.getHelpById$(this.id).subscribe(data => {
      if (data.success === false) {
      } else {
        this.problemsData = data.data;
      }
      
    });
 
  this._helpService.updateAllUnread(this.id,this._helpService.getUserId()).subscribe(data=>{});
  this.loading = true;
  this.finished = true;
  this.getProblemscomments();
  /*
  this._helpService.getHelpcommentById$().subscribe(data => {
      if (data.success === false) {
      } else {
        this.problemsData1 = data.data;
        //this.replyFor = ((this.problemsData1).length) ? this.problemsData1[(this.problemsData1).length-1].pcid : null;
      }
    });*/
    (this.apiEvents).push(apiEvent); 


  }
 




  
onNotify(msgRec) {
    this.problemsData1.push(msgRec);
  }

reply1() {
    this.reply = true;
    this.isPushed = true;
  }


  replyToUpdate(obj){        
    this.replyFor = obj.rid; 
    this.problemsData1.push(obj.newComment);
    this.reply = this.isPushed = false;
  }


  public ngonDestory (){
    if((this.apiEvents).length){
      this.apiEvents.forEach(val=>{
        val.unsubscribe();
      })

    }
    
  }
}