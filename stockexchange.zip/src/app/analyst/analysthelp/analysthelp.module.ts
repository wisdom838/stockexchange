import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AnalysthelpRoutingModule } from './analysthelp-routing.module';
import { AnalysthelpFormComponent } from './analysthelp-form/analysthelp-form.component';
import { AnalysthelpViewComponent } from './analysthelp-view/analysthelp-view.component';
import { AnalysthelpListComponent } from './analysthelp-list/analysthelp-list.component';
import { DataTablesModule } from 'angular-datatables';
import { RepeatModule } from '../../repeat/repeat.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DropzoneModule } from 'ngx-dropzone-wrapper';
import { AnalysthelpreplyFormComponent } from './analysthelpreply-form/analysthelpreply-form.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

@NgModule({
  imports: [
    CommonModule,
    AnalysthelpRoutingModule,
    DataTablesModule,
    RepeatModule,
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    DropzoneModule,
    //InfiniteScrollModule
  ],
  declarations: [
    AnalysthelpFormComponent, 
    AnalysthelpViewComponent,
    AnalysthelpListComponent,
    AnalysthelpreplyFormComponent
  ]
})
export class AnalysthelpModule { }
