import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalysthelpFormComponent } from './analysthelp-form.component';

describe('AnalysthelpFormComponent', () => {
  let component: AnalysthelpFormComponent;
  let fixture: ComponentFixture<AnalysthelpFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalysthelpFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalysthelpFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
