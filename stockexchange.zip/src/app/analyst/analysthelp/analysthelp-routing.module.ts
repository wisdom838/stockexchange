import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AnalysthelpFormComponent } from './analysthelp-form/analysthelp-form.component';
import { AnalysthelpListComponent } from './analysthelp-list/analysthelp-list.component';
import { AnalysthelpViewComponent } from './analysthelp-view/analysthelp-view.component';
const routes: Routes = [
  { path: '', component: AnalysthelpListComponent },
  {
    path: 'create', component: AnalysthelpFormComponent,
    data: {
      breadcrumb: 'Create'
    },
  },
  {
    path: 'read/:id', component: AnalysthelpViewComponent,
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnalysthelpRoutingModule { }
