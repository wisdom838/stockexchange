import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from './../../../services/user.service';
import { UtilsService } from './../../../services/utils.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { ClientModel } from './../../../models/client.model';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';

import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ENV } from './../../../env.config';
import { RequestOptions } from '@angular/http';
import { ToastsManager } from 'ng2-toastr/src/toast-manager';
import { IUser } from '../../../services/user';



@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  routeSub: Subscription;
  clientForm: FormGroup;
  public currentUser: IUser;
  filesToUpload: Array<File>;
  private id: number;
  error: boolean;
  edit1: boolean;
  loading: boolean;
  userSub: Subscription;
  userprofile: ClientModel;
  public serverURL = ENV.SERVER_URL;
  public avatar: string = null;
  dynamicImg: string = 'assets/img/avatar5.png';

  @ViewChild('fileInput') fileInput;

  constructor(private http: HttpClient,
    private _userapi: UserService,
    public utils: UtilsService,
    public toastr: ToastsManager) {
    this.filesToUpload = [];
    this.clientForm = new FormGroup({

    });
  }

  ngOnInit() {
    this.edit1 = false;
    this.id = this._userapi.getCurUserId();
    this._getUser();
    this.getAvatar();
  }

  getAvatar() {
    let id = this._userapi.getCurUserId();
    this._userapi.getUserById$(id).subscribe((data) => {
      this.dynamicImg = ((data.data.profile_pic != undefined) && (data.data.profile_pic.length))
        ? ENV.SERVER_URL + data.data.profile_pic
        : this.dynamicImg;


    });
  }

  edit() {
    this.edit1 = true;
  }
  cancel() {
    this.edit1 = false;

  }

  updated(data) {
    this.cancel();
    this.userprofile = data;
  }


  fileChangeEvent() {
    let fileBrowser = this.fileInput.nativeElement;

    if (fileBrowser.files && fileBrowser.files[0]) {
      const formData = new FormData();

      formData.append("profile_pic", this.fileInput.nativeElement.files[0], this.fileInput.nativeElement.files[0].name);
      formData.append("id", String(this.id));
      this._userapi.upload(formData).subscribe(res => {
        if (res.success) {
          this.utils.updateUserSession(res.data);
          this.dynamicImg = ENV.SERVER_URL + res.data.profile_pic;
          let that = this;
          $('.user-image,.img-circle').each(function () {
            $(this).attr('src', that.dynamicImg)
          });
          this.toastr.success(res.message, 'Success');
        }
        else {
          this.toastr.error(res.message, 'Error');
        }
      });
    }
  }

  onEdit(): void {
    this._getUser();
    this.edit1 = false;

  }
  private _getUser() {
    this.loading = true;
    // GET event by ID
    this.userSub = this._userapi
      .getUserById$(this.id)
      .subscribe(
        res => {

          if (res.success) {
            this.userprofile = res.data;
            this.avatar = this.serverURL + this.userprofile.profile_pic;
          }
          this.loading = false;
        },
        err => {
          this.loading = false;
          this.error = true;
        }
      );
  }
}
