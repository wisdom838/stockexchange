import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AnalystLayoutComponent } from '../analyst-layout/analyst-layout.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ProfileComponent } from './profile/profile.component';
import { AnalystNotificationsComponent } from './analyst-notifications/analyst-notifications.component';

const routes: Routes = [
  {
    path: 'change-password', component: ChangePasswordComponent,
    data: {
      breadcrumb: 'changePassword'
    }
  },
  {
    path: 'profile', component: ProfileComponent,
    data: {
      breadcrumb: 'Profile'
    }
  },
  {
    path: 'notifications', component:AnalystNotificationsComponent,
    data: {
      breadcrumb: 'Notifications'
    },
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SettingsRoutingModule { }
