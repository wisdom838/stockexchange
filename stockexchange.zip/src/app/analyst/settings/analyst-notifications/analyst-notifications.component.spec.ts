import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalystNotificationsComponent } from './analyst-notifications.component';

describe('AnalystNotificationsComponent', () => {
  let component: AnalystNotificationsComponent;
  let fixture: ComponentFixture<AnalystNotificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalystNotificationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalystNotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
