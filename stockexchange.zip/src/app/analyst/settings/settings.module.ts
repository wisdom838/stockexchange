import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SettingsRoutingModule } from './settings-routing.module';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ProfileComponent } from './profile/profile.component';
import { EditComponent } from './profile/edit/edit.component';
import { AnalystNotificationsComponent } from './analyst-notifications/analyst-notifications.component';
import { RepeatModule } from '../../repeat/repeat.module';


@NgModule({
  imports: [
    CommonModule,
    SettingsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RepeatModule

  ],
  declarations: [ChangePasswordComponent, ProfileComponent, EditComponent, AnalystNotificationsComponent]
})
export class SettingsModule { }
