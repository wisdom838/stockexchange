import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalystLockerFormComponent } from './analyst-locker-form.component';

describe('AnalystLockerFormComponent', () => {
  let component: AnalystLockerFormComponent;
  let fixture: ComponentFixture<AnalystLockerFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalystLockerFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalystLockerFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
