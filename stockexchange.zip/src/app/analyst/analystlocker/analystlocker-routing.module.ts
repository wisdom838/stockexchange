import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AnalystLockerFormComponent } from './analyst-locker-form/analyst-locker-form.component';
import { AnalystLockersListComponent } from './analyst-lockers-list/analyst-lockers-list.component';

const Routes: Routes = [

  // { path: 'create', component: CreateHelpFormComponent },
  {
    path: '', component: AnalystLockerFormComponent,
    data: {
      breadcrumb: 'Lockers'
    }
  },

  {
    path: 'create', component: AnalystLockersListComponent,
    data: {
      breadcrumb: 'Create'
    }
  },


];
@NgModule({
  imports: [RouterModule.forChild(Routes)],
  exports: [RouterModule]
})
export class AnalystlockerRoutingModule { }
