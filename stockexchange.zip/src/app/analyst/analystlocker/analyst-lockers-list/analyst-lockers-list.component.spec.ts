import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalystLockersListComponent } from './analyst-lockers-list.component';

describe('AnalystLockersListComponent', () => {
  let component: AnalystLockersListComponent;
  let fixture: ComponentFixture<AnalystLockersListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalystLockersListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalystLockersListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
