import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LockersService } from '../../../services/lockers.service';
import { UtilsService } from '../../../services/utils.service';
import { LockerModel, FormLockerModel } from './../../../models/locker.model';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Meta } from '@angular/platform-browser';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

@Component({
  selector: 'app-analyst-lockers-list',
  templateUrl: './analyst-lockers-list.component.html',
  styleUrls: ['./analyst-lockers-list.component.css']
})
export class AnalystLockersListComponent implements OnInit {

  objLen:number = 10;
  dtOptions = { 
    "draw": 1, 
    "columns": [
      { "data": "title", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
      { "data": "typeId", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
      { "data": "note", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
      { "data": "url", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
      { "data": "createdBy", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } },
      { "data": "id", "name": "", "searchable": true, "orderable": true, "search": { "value": "", "regex": false } }],
      "order": [
          { "column": "createdAt", "dir": "desc" }
      ],
      "start": 0,
      "length": this.objLen,
      "search": { "value": "", "regex": false }
    };
  finished = false  // boolean when end of database is reached

  error: boolean;
  apiEvents = [];
  lockers= [];
  switch:string = '';
  
  lockerFilterForm: FormGroup = this.fb.group({
    sortBy: ['recent'],
    status: [''],
    quickFilter: [''],
  });


  constructor(
    private http: HttpClient,
    private _lockerService: LockersService,
    private _utils: UtilsService,
    private meta: Meta,
    public toastr: ToastsManager,
    private fb: FormBuilder
  ) { }

  ngOnInit() {
    let currentUser = JSON.parse(localStorage.getItem('currentUser'));
    this.dtOptions.columns[3].search['value'] = currentUser.user.userid;
    this.getLockers();
    this.onChanges();
    
  }

  onChanges(){
    this.lockerFilterForm.valueChanges
              .debounceTime(500)
              .distinctUntilChanged()
              .subscribe(val => {
      this.dtOptions.columns[1].search['value'] = val.status;
      this.dtOptions.search = { "value": val.quickFilter, "regex": false };
      this.dtOptions.order[0].dir = (val.sortBy === 'recent') ? "desc" : 'asc';
      this.dtOptions.start = 0;
      this.dtOptions.length = this.objLen;
      this.finished = false;
      this.lockers = [];      
      this.getLockers();
    });
  }

  onScroll () {
    this.dtOptions.start += this.objLen;
    this.getLockers();
  }

  private getLockers(append=true) {
    if (this.finished) return;
    this._lockerService
        .filterLockers$(this.dtOptions,'filter-lockers')
        .subscribe(data => {          
          if(data.data.length !== this.objLen){
            this.finished = true;
          }
          this.lockers = (this.lockers).concat(data.data);
        })        
  }
}


