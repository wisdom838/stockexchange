import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RepeatModule } from '../../repeat/repeat.module';
import { DropzoneModule } from 'ngx-dropzone-wrapper';
import { AnalystlockerRoutingModule } from './analystlocker-routing.module';
import { AnalystLockerFormComponent } from './analyst-locker-form/analyst-locker-form.component';
import { AnalystLockersListComponent } from './analyst-lockers-list/analyst-lockers-list.component';

@NgModule({
  imports: [
    CommonModule,
    RepeatModule,
    FormsModule,
    ReactiveFormsModule,
    DropzoneModule,
    AnalystlockerRoutingModule
  ],
  declarations: [AnalystLockerFormComponent, AnalystLockersListComponent]
})
export class AnalystlockerModule { }
