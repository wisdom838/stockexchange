import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-analyst',
  templateUrl: './view-analyst.component.html',
  styleUrls: ['./view-analyst.component.css']
})
export class ViewAnalystComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
