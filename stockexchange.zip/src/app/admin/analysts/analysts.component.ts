import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analysts',
  templateUrl: './analysts.component.html',
  styleUrls: ['./analysts.component.css']
})
export class AnalystsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
