import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-editorier',
  templateUrl: './view-editorier.component.html',
  styleUrls: ['./view-editorier.component.css']
})
export class ViewEditorierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
