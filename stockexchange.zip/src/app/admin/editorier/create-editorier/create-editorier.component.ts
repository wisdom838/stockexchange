import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-editorier',
  templateUrl: './create-editorier.component.html',
  styleUrls: ['./create-editorier.component.css']
})
export class CreateEditorierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
