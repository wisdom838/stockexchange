import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-admin',
  templateUrl: './view-admin.component.html',
  styleUrls: ['./view-admin.component.css']
})
export class ViewAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
