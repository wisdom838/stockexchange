import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createcountries',
  templateUrl: './createcountries.component.html',
  styleUrls: ['./createcountries.component.css']
})
export class CreatecountriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
