import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-create-analyst-company',
  templateUrl: './create-analyst-company.component.html',
  styleUrls: ['./create-analyst-company.component.css']
})
export class CreateAnalystCompanyComponent implements OnInit {

  pageTitle = 'Create Event';

  constructor(private title: Title) { }

  ngOnInit() {
    this.title.setTitle(this.pageTitle);
  }

}
