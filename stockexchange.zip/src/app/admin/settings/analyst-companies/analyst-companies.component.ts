import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analyst-companies',
  templateUrl: './analyst-companies.component.html',
  styleUrls: ['./analyst-companies.component.css']
})
export class AnalystCompaniesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}