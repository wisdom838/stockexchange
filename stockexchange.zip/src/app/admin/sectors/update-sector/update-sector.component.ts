import { Component, OnInit } from '@angular/core';
import { UtilsService } from './../../../services/utils.service';
import { Subscription } from 'rxjs/Subscription';
import { SectorModel } from './../../../models/sector.model';
import { SectorsService } from './../../../services/sectors.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-update-sector',
  templateUrl: './update-sector.component.html',
  styleUrls: ['./update-sector.component.css']
})
export class UpdateSectorComponent implements OnInit {

  sectors : SectorModel;
  private id: number;
  routeSub: Subscription;
  loading: boolean;
  sectorsSub: Subscription;
  error: boolean;
  
  
    constructor(  private route: ActivatedRoute,  
                 private _sectorsapi: SectorsService,
                  public utils: UtilsService) { }
  
    ngOnInit() {
      this.routeSub = this.route.params
      .subscribe(params => {
        this.id = params['id'];
        this._getSectors();
      });
    }
  
    private _getSectors() {
      this.loading = true;
      // GET event by ID
      this.sectorsSub = this._sectorsapi
        .getSectorById$(this.id)
        .subscribe(
          res => {
            if(res.success){
              this.sectors= res.data;         
            }          
            this.loading = false;
          },
          err => {
            this.loading = false;
            this.error = true;
          }
        );
    }
    
    ngOnDestroy() {
      this.routeSub.unsubscribe();
      //this.tabSub.unsubscribe();
      this.sectorsSub.unsubscribe();
    }
  }

