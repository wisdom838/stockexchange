import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-create-ticker',
  templateUrl: './create-ticker.component.html',
  styleUrls: ['./create-ticker.component.css']
})
export class CreateTickerComponent implements OnInit {

  pageTitle = 'Create Event';

  constructor(private title: Title) { }

  ngOnInit() {
    this.title.setTitle(this.pageTitle);
  }

}
