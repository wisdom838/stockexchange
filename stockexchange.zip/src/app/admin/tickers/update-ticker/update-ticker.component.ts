import { Component, OnInit,OnDestroy } from '@angular/core';

import { Title } from '@angular/platform-browser';
//import { AuthService } from './../../../auth/auth.service';
import { TickerService } from './../../../services/ticker.service';
import { UtilsService } from './../../../services/utils.service';


import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { TickerModel } from './../../../models/ticker.model';

@Component({
  selector: 'app-update-ticker',
  templateUrl: './update-ticker.component.html',
  styleUrls: ['./update-ticker.component.css']
})
export class UpdateTickerComponent implements OnInit {

  pageTitle = 'Update Event';
  routeSub: Subscription;
  private id: number;
  loading: boolean;
  tickerSub: Subscription;
  ticker: TickerModel;
  error: boolean;

  constructor(
    private route: ActivatedRoute,    
    private title: Title,
    private _tickerapi: TickerService,
    public utils: UtilsService
  ) { }

  ngOnInit() {

    this.title.setTitle(this.pageTitle);
    // Set event ID from route params and subscribe
    this.routeSub = this.route.params
      .subscribe(params => {
        this.id = params['id'];
        this._getTicker();
      });
  }


  private _getTicker() {
    this.loading = true;
    // GET event by ID
    this.tickerSub = this._tickerapi
      .getUserById$(this.id)
      .subscribe(
        res => {
          if(res.success){
            this.ticker = res.data; 
          }          
          this.loading = false;
        },
        err => {
          this.loading = false;
          this.error = true;
        }
      );
  }

  ngOnDestroy() {
    this.routeSub.unsubscribe();
    //this.tabSub.unsubscribe();
    this.tickerSub.unsubscribe();
  }

}
