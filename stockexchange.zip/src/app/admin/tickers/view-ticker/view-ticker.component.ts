import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-ticker',
  templateUrl: './view-ticker.component.html',
  styleUrls: ['./view-ticker.component.css']
})
export class ViewTickerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
