import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tickers',
  templateUrl: './tickers.component.html',
  styleUrls: ['./tickers.component.css']
})
export class TickersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
