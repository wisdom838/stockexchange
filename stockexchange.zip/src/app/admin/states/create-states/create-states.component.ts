import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-states',
  templateUrl: './create-states.component.html',
  styleUrls: ['./create-states.component.css']
})
export class CreateStatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
