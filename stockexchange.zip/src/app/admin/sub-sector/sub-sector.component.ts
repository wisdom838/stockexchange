import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-sector',
  templateUrl: './sub-sector.component.html',
  styleUrls: ['./sub-sector.component.css']
})
export class SubSectorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
