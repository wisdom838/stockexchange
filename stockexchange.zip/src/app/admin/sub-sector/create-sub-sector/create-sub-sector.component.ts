import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-sub-sector',
  templateUrl: './create-sub-sector.component.html',
  styleUrls: ['./create-sub-sector.component.css']
})
export class CreateSubSectorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
